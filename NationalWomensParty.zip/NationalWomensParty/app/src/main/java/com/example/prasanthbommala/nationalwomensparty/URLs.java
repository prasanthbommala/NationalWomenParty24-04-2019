package com.example.prasanthbommala.nationalwomensparty;

public class URLs {
    public static final String URL_GET_STATES= "https://nationalwomenspartyindia.org/api/members/states";
    public static final String URL_GET_DISTRICTS= "https://nationalwomenspartyindia.org/api/members/districts";
    public static final String URL_POST_LOGIN= "https://nationalwomenspartyindia.org/api/members/login";
    public static final String URL_POST_SIGN_UP= "https://nationalwomenspartyindia.org/api/members/save";
}
