package com.example.prasanthbommala.nationalwomensparty;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class OTPValidationFragment extends Fragment {
    EditText otpValidationPin;
    TextView otpValidationPhoneNumber;
    Button otpValidationPinsubmit;
    FragmentManager fm;
    public OTPValidationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_otpvalidation, container, false);
        otpValidationPin = (EditText) view.findViewById(R.id.otpValidationPin);
        otpValidationPhoneNumber = (TextView) view.findViewById(R.id.otpValidationPhoneNumber);
        otpValidationPinsubmit = (Button) view.findViewById(R.id.otpValidationPinSubmit);
        otpValidationPinsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fm = getActivity().getSupportFragmentManager();
                Fragment signUpMemberShipFragment = new SignUpMemberShipFragment();
                fm.beginTransaction().replace(R.id.home_container,signUpMemberShipFragment).addToBackStack(null).commit();
            }
        });
        return view;
    }

}
