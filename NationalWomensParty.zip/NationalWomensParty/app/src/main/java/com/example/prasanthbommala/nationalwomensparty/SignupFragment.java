package com.example.prasanthbommala.nationalwomensparty;


import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static android.provider.Telephony.Mms.Part.TEXT;
import static com.android.volley.VolleyLog.TAG;


/**
 * A simple {@link Fragment} subclass.
 */
public class SignupFragment extends Fragment {
    EditText dateSelection;
    DatePickerDialog picker;
    FragmentManager fm;
    private ProgressDialog pDialog;
    View view;
    Array states;
    String callFrom;
    Button signUp;
    ArrayList<String> StateName;
    EditText firstNameEditText, lastNameEditText, emailEditText, passwordEditText, dateOfBirthEditText, districtEditText, constituencyEditText, phoneNumberEditText, voterIdEditText;
    Spinner genderSpinner, stateSpinner,districtSpinner;
    String firstName, lastname, email, password, dateOfBirth, district, constitunecy, phoneNumber, voterId, gender, state;
    TextView example;

    public SignupFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.sign_up_layout, container, false);
        initUI();
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intializeReqValues();
                showTheProgressDialog();
                memberSignUP();
                hideDialog();
            }
        });
        dateSelection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dateofBirthSelection();
            }
        });
        stateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedStateId = Integer.toString(position+1);
                String country=   stateSpinner.getItemAtPosition(stateSpinner.getSelectedItemPosition()).toString();
                Toast.makeText(getActivity().getApplicationContext(),selectedStateId,Toast.LENGTH_LONG).show();
                String districtURL = URLs.URL_GET_DISTRICTS +"/"+ selectedStateId;
                callFrom = "DISTRICT";
                loadServerCities(districtURL,callFrom);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        return view;
    }

    public void initUI() {
        dateSelection = (EditText) view.findViewById(R.id.date_of_birth);
        dateSelection.setInputType(InputType.TYPE_NULL);
        firstNameEditText = (EditText) view.findViewById(R.id.firstName);
        lastNameEditText = (EditText) view.findViewById(R.id.lastName);
        emailEditText = (EditText) view.findViewById(R.id.email);
        dateOfBirthEditText = (EditText) view.findViewById(R.id.date_of_birth);
        genderSpinner = (Spinner) view.findViewById(R.id.genderSpinner);
        stateSpinner = (Spinner) view.findViewById(R.id.stateSpinner);
        districtSpinner = (Spinner) view.findViewById(R.id.districtSpinner);
        constituencyEditText = (EditText) view.findViewById(R.id.constituency);
        phoneNumberEditText = (EditText) view.findViewById(R.id.phone);
        voterIdEditText = (EditText) view.findViewById(R.id.voterId);
        signUp = (Button) view.findViewById(R.id.signUpBtn);
        example = (TextView) view.findViewById(R.id.example);
        pDialog = new ProgressDialog(getActivity());
        pDialog.setCancelable(false);
        StateName=new ArrayList<>();
        callFrom = "STATE";
        loadServerCities(URLs.URL_GET_STATES,callFrom);
    }
    public void loadServerCities(String loadUrl,String callValue){
        String tag_json_arry = "json_array_req";
        String url = loadUrl;
      final  String callVal = callValue;
      final  ArrayList<String> DistrictName = new ArrayList<>();
        JsonArrayRequest req = new JsonArrayRequest (Request.Method.GET,url,
                null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //Toast.makeText(getActivity(), "JSON Response:-" +response.toString(), Toast.LENGTH_SHORT).show();
                try {
                    for(int i=0;i<response.length();i++){
                        // Get current json object
                        JSONObject state = response.getJSONObject(i);
                        if(callVal=="STATE") {
                            String stateFromServer = state.getString("st_name");
                            StateName.add(stateFromServer);
                        } else {
                            String districtFromServer = state.getString("dist_name");
                            DistrictName.add(districtFromServer);
                        }
                    }
                    if(callVal=="STATE") {
                        stateSpinner.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, StateName));
                    } else {
                        districtSpinner.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, DistrictName));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){

            /**
             * Passing some request headers
             */
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("NWP-API-KEY", "123456");
                headers.put("Content-Type", "application/json");
                return headers;
            }
        };
        //VolleySingleton.getInstance(getActivity()).addToRequestQueue(req);
        AppController.getInstance().addToRequestQueue(req, tag_json_arry);
    }
    public void intializeReqValues(){
        firstName = firstNameEditText.getText().toString();
        lastname = lastNameEditText.getText().toString();
        email = emailEditText.getText().toString();
        dateOfBirth = dateOfBirthEditText.getText().toString();
        district = districtSpinner.getSelectedItem().toString();
        constitunecy = constituencyEditText.getText().toString();
        phoneNumber = phoneNumberEditText.getText().toString();
        voterId = voterIdEditText.getText().toString();
        gender = genderSpinner.getSelectedItem().toString();
        state = stateSpinner.getSelectedItem().toString();
    }
//    public void memberSignUP() {
//        Map<String, String> params = new HashMap();
//        params.put("title","Mr");
//        params.put("fname","prasa");
//        params.put("lname","bomm");
//        params.put("email","r@gmail.com");
//        params.put("date_of_birth","1986-01-01 12:30:00");
//        params.put("gender","m");
//        params.put("state_id","1");
//        params.put("district_id","10");
//        params.put("constituency","Kotabommali");
//        params.put("phone","9398001606");
//        params.put("voter_id","VT123");
//        params.put("membership_id","REF123");
//        params.put("ac_num","");
//        params.put("blood_group","B+");
//    JSONObject parameters = new JSONObject(params);
//        Toast.makeText(getActivity(), "JSON Request:-" +parameters, Toast.LENGTH_SHORT).show();
//            JsonObjectRequest req = new JsonObjectRequest (Request.Method.POST, URLs.URL_POST_SIGN_UP, parameters,
//                    new Response.Listener<JSONObject>() {
//                        @Override
//                        public void onResponse(JSONObject response) {
//                            try {
//                                JSONObject obj = response.getJSONObject("message");
//                                // Retrieves the string labeled "colorName" and "description" from
//                                //the response JSON Object
//                                //and converts them into javascript objects
//                               // String color = obj.getString("colorName");
//                                example.setText("String Response : " + obj.toString());
//                            }catch (JSONException e){
//
//                            }
//                        }
//                    }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//                    example.setText(error.getMessage());
//                }
//            }){
//                /**
//                 * Passing some request headers
//                 */
//                @Override
//                public Map<String, String> getHeaders() throws AuthFailureError {
//                    HashMap<String, String> headers = new HashMap<String, String>();
//                    headers.put("NWP-API-KEY", "123456");
//                    headers.put("Content-Type", "application/json");
//                    return headers;
//                }
//            };
//            req.setTag(TAG);
//            VolleySingleton.getInstance(getActivity()).addToRequestQueue(req);
//        }


    public void memberSignUP() {
//        Map<String, String> params = new HashMap<String, String>();
//        params.put("title","Mr");
//        params.put("fname","prasa");
//        params.put("lname","bomm");
//        params.put("email","r@gmail.com");
//        params.put("date_of_birth","1986-01-01 12:30:00");
//        params.put("gender","m");
//        params.put("state_id","1");
//        params.put("district_id","10");
//        params.put("constituency","Kotabommali");
//        params.put("phone","9398001606");
//        params.put("voter_id","VT123");
//        params.put("membership_id","REF123");
//        params.put("ac_num","");
//        params.put("blood_group","B+");
//        JSONObject jsonObj = new JSONObject(params);
        String tag_json_obj= "STRING_POST_REQUEST";
        StringRequest postRequest = new StringRequest(Request.Method.POST, URLs.URL_POST_SIGN_UP,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        // response
                        Log.d("Response", response);
                        example.setText("Response Sucess:-" +response);
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d("Error.Response", error.getMessage());
                        example.setText("Response failure:-" +error.getMessage());
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("title","Mr");
                params.put("fname","prasa");
                params.put("lname","bomm");
                params.put("email","r@gmail.com");
                params.put("date_of_birth","1986-01-01 12:30:00");
                params.put("gender","m");
                params.put("state_id","1");
                params.put("district_id","10");
                params.put("constituency","Kotabommali");
                params.put("phone","9398001606");
                params.put("voter_id","VT123");
                params.put("membership_id","REF123");
                params.put("ac_num","");
                params.put("blood_group","B+");
                return params;
            }
            @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("NWP-API-KEY", "123456");
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
        };
        AppController.getInstance().addToRequestQueue(postRequest, tag_json_obj);
    }

    public void memberJSONSignUP() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("title","Mr");
        params.put("fname","prasa");
        params.put("lname","bomm");
        params.put("email","r@gmail.com");
        params.put("date_of_birth","1986-01-01 12:30:00");
        params.put("gender","m");
        params.put("state_id","1");
        params.put("district_id","10");
        params.put("constituency","Kotabommali");
        params.put("phone","9398001606");
        params.put("voter_id","VT123");
        params.put("membership_id","REF123");
        params.put("ac_num","");
        params.put("blood_group","B+");
        JSONObject jsonObj = new JSONObject(params);
        String tag_json_obj= "JSON_POST_REQUEST";
        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, URLs.URL_POST_SIGN_UP,
               jsonObj, new Response.Listener<JSONObject>()
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        // response
                     //   Log.d("Response", response);
                        example.setText("Response Sucess:-" +response);
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d("Error.Response", error.getMessage());
                        example.setText("Response failure:-" +error.getMessage());
                    }
                }
        )
        {
//            @Override
//            protected Map<String, String> getParams() {
//                Map<String, String> params = new HashMap<String, String>();
//                params.put("title","Mr");
//                params.put("fname","prasa");
//                params.put("lname","bomm");
//                params.put("email","r@gmail.com");
//                params.put("date_of_birth","1986-01-01 12:30:00");
//                params.put("gender","m");
//                params.put("state_id","1");
//                params.put("district_id","10");
//                params.put("constituency","Kotabommali");
//                params.put("phone","9398001606");
//                params.put("voter_id","VT123");
//                params.put("membership_id","REF123");
//                params.put("ac_num","");
//                params.put("blood_group","B+");
//                return params;
//            }
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("NWP-API-KEY", "123456");
                headers.put("Content-Type", "application/json");
                return headers;
            }
        };
        AppController.getInstance().addToRequestQueue(postRequest, tag_json_obj);
    }
    public void dateofBirthSelection(){
        final Calendar cldr = Calendar.getInstance();
        int day = cldr.get(Calendar.DAY_OF_MONTH);
        int month = cldr.get(Calendar.MONTH);
        int year = cldr.get(Calendar.YEAR);
        // date picker dialog
        picker = new DatePickerDialog(getActivity(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        dateSelection.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    }
                }, year, month, day);
        picker.show();
    }
    public void showTheProgressDialog(){
        pDialog.setMessage("Signing up....");
        pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
}
