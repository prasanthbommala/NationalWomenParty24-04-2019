package com.example.prasanthbommala.nationalwomensparty;

public class MyData {
    static String[] nameArray = {"National Womens party", "National Womens party", "National Womens party", "National Womens party", "National Womens party", "National Womens party", "National Womens party","National Womens party", "National Womens party", "National Womens party", "National Womens party"};

    static Integer[] drawableArray = {R.drawable.nationalwomensimage, R.drawable.nationalwomensimage, R.drawable.nationalwomensimage,
            R.drawable.nationalwomensimage, R.drawable.nationalwomensimage, R.drawable.nationalwomensimage, R.drawable.nationalwomensimage,
            R.drawable.nationalwomensimage, R.drawable.nationalwomensimage, R.drawable.nationalwomensimage,R.drawable.nationalwomensimage};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
}
