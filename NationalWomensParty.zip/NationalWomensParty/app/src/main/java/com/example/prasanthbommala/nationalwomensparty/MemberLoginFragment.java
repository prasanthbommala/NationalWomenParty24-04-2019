package com.example.prasanthbommala.nationalwomensparty;


import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static com.android.volley.VolleyLog.TAG;


/**
 * A simple {@link Fragment} subclass.
 */
public class MemberLoginFragment extends DialogFragment {
    EditText loginMemberOrPhone,phonePinNumber;
    Button loginSubmit,loginSignupSubmit;
    TextView forgetOnClick;
    FragmentManager fm;
    String loginOTP,loginPhoneNumber;
    public MemberLoginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view =    inflater.inflate(R.layout.fragment_member_login, container, false);
        loginMemberOrPhone = (EditText) view.findViewById(R.id.loginMemberIdorPhone);
        phonePinNumber = (EditText) view.findViewById(R.id.loginPhoneNumberPin);
        loginSubmit = (Button)view.findViewById(R.id.loginSubmitBtn);
        loginSignupSubmit = (Button) view.findViewById(R.id.loginSignUpSubmit);
        forgetOnClick = (TextView) view.findViewById(R.id.loginForgotPinClickHere);
        loginSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               validateLogin();
//                fm = getActivity().getSupportFragmentManager();
//                Fragment signUpMemberShipFragment = new SignUpMemberShipFragment();
//                fm.beginTransaction().replace(R.id.home_container,signUpMemberShipFragment).addToBackStack(null).commit();
            }
        });
        loginSignupSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fm = getActivity().getSupportFragmentManager();
                Fragment signupFragment = new SignupFragment();
                fm.beginTransaction().replace(R.id.home_container,signupFragment).addToBackStack(null).commit();
            }
        });
        forgetOnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fm = getActivity().getSupportFragmentManager();
                Fragment forgetPinFragment = new ForgetPinFragment();
                fm.beginTransaction().replace(R.id.home_container,forgetPinFragment).addToBackStack(null).commit();
            }
        });
        return view;
    }
 public void validateLogin(){
      loginOTP = phonePinNumber.getText().toString();
      loginPhoneNumber = loginMemberOrPhone.getText().toString();
//     Map<String, String> params = new HashMap<String, String>();
//     params.put("otp",loginOTP);
//     params.put("phone",loginPhoneNumber);
//     JSONObject json = new JSONObject(params);
//     try {
//         String otp = json.getString("otp");
//         Toast.makeText(getActivity(), otp, Toast.LENGTH_SHORT).show();
//     } catch (JSONException e) {
//         e.printStackTrace();
//     }

     JsonObjectRequest req = new JsonObjectRequest (Request.Method.POST,URLs.URL_POST_LOGIN,null, new Response.Listener<JSONObject>() {
         @Override
         public void onResponse(JSONObject response) {
             Toast.makeText(getActivity(), "JSON Response:-" +response.toString(), Toast.LENGTH_SHORT).show();
             try {

               String memberId = response.getString("MemberId");
             } catch (JSONException e) {
                 e.printStackTrace();
             }
         }
     }, new Response.ErrorListener() {
         @Override
         public void onErrorResponse(VolleyError error) {
             Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_SHORT).show();
         }
     }){
         @Override
         protected Map<String, String> getParams() {
             Map<String, String> params = new HashMap<String, String>();
             params.put("otp",loginOTP);
             params.put("phone",loginPhoneNumber);

             return params;
         }
         /**
          * Passing some request headers
          */
         @Override
         public Map<String, String> getHeaders() throws AuthFailureError {
             HashMap<String, String> headers = new HashMap<String, String>();
             headers.put("NWP-API-KEY", "123456");
             headers.put("Content-Type", "application/json");
             return headers;
         }
     };
     req.setTag(TAG);
     VolleySingleton.getInstance(getActivity()).addToRequestQueue(req);
 }
}
