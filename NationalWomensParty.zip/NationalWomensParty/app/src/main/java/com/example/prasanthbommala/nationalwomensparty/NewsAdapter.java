package com.example.prasanthbommala.nationalwomensparty;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class NewsAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private ArrayList<DataModel> dataSet;

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView textViewName;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.textViewName = (TextView) itemView.findViewById(R.id.textViewName);


        }
    }

    public NewsAdapter(ArrayList<DataModel> data) {
        this.dataSet = data;
    }

    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                         int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.news_card_layout, parent, false);

        //view.setOnClickListener(MainActivity.myOnClickListener);

        CustomAdapter.MyViewHolder myViewHolder = new CustomAdapter.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final CustomAdapter.MyViewHolder holder, final int listPosition) {

        TextView textViewName = holder.textViewName;



        textViewName.setText(dataSet.get(listPosition).getName());


    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }
}

